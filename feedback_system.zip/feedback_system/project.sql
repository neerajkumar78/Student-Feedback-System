-- MySQL dump 10.13  Distrib 5.7.23, for Win64 (x86_64)
--
-- Host: localhost    Database: project
-- ------------------------------------------------------
-- Server version	5.7.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `name` varchar(20) DEFAULT NULL,
  `adminId` int(11) NOT NULL,
  `sex` varchar(5) NOT NULL,
  `phno` bigint(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) DEFAULT NULL,
  `validity` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`adminId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES ('NEERAJ KUMAR',1001,'M',6260305279,'1stjuneadvjava@gmail.com','$2y$10$gjhgjhghjghjghlkjljklenZ3nLWocDEmhOsmuowALTJFGJOBUYaG',NULL);
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `belongcourse`
--

DROP TABLE IF EXISTS `belongcourse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `belongcourse` (
  `dId` int(11) NOT NULL,
  `cCode` varchar(11) NOT NULL,
  PRIMARY KEY (`dId`,`cCode`),
  KEY `dId` (`dId`),
  KEY `cCode` (`cCode`),
  CONSTRAINT `belongcourse_ibfk_1` FOREIGN KEY (`cCode`) REFERENCES `courses` (`cCode`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `belongcourse_ibfk_2` FOREIGN KEY (`dId`) REFERENCES `department` (`dId`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `belongcourse`
--

LOCK TABLES `belongcourse` WRITE;
/*!40000 ALTER TABLE `belongcourse` DISABLE KEYS */;
INSERT INTO `belongcourse` VALUES (1001,'CSE221'),(1001,'CSE222'),(1001,'CSE223'),(1001,'CSE224'),(1002,'ECE221'),(1002,'ECE222'),(1002,'ECE223'),(1003,'EE321'),(1003,'EE322'),(1004,'ME221'),(1004,'ME222');
/*!40000 ALTER TABLE `belongcourse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `courses` (
  `cCode` varchar(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `sem` int(11) DEFAULT NULL,
  `noOfLecture` int(11) DEFAULT NULL,
  `dId` int(11) DEFAULT NULL,
  PRIMARY KEY (`cCode`),
  KEY `cCode` (`cCode`),
  KEY `dId` (`dId`),
  CONSTRAINT `courses_ibfk_1` FOREIGN KEY (`dId`) REFERENCES `department` (`dId`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses`
--

LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` VALUES ('CSE221','DBMS',4,35,1001),('CSE222','CA',4,35,1001),('CSE223','TOC',4,35,1001),('CSE224','PBQT',4,35,1001),('CSE225','Operating System',5,40,1001),('ECE221','NETWORK',4,35,1002),('ECE222','DS',4,35,1002),('ECE223','AURDINO',4,35,1002),('EE321','TRANSFORMRER',6,35,1003),('EE322','CIRCUIT',6,30,1003),('ME221','DOM',4,35,1004),('ME222','KUCH BHI',4,35,1004);
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `department` (
  `dId` int(11) NOT NULL,
  `dName` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`dId`),
  KEY `dId` (`dId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
INSERT INTO `department` VALUES (1001,'COMPUTER SCIENCE'),(1002,'ELECTRONICS'),(1003,'ELECRICAL'),(1004,'MECHANICAL'),(1005,'Chemical Engineering');
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faculty`
--

DROP TABLE IF EXISTS `faculty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faculty` (
  `facultyId` int(11) NOT NULL,
  `post` varchar(20) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `sex` char(1) DEFAULT NULL,
  `dId` int(11) DEFAULT NULL,
  `qualification` varchar(100) DEFAULT NULL,
  `areaOfInterest` varchar(100) DEFAULT NULL,
  `experience` int(11) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phno` bigint(10) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `validity` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`facultyId`),
  KEY `dId` (`dId`),
  CONSTRAINT `faculty_ibfk_1` FOREIGN KEY (`dId`) REFERENCES `department` (`dId`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faculty`
--

LOCK TABLES `faculty` WRITE;
/*!40000 ALTER TABLE `faculty` DISABLE KEYS */;
INSERT INTO `faculty` VALUES (121,'professor','NILAY KHARE','M',1001,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(122,'assistant professor','JTC','M',1001,NULL,NULL,NULL,NULL,NULL,'$2y$10$gjhgjhghjghjghlkjljkle0TV653jDbsLG18lPro.UYLil0C9vkAy',NULL),(123,'assistant professor','NAMITA TIWARI','F',1001,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(124,'contract faculty','GAURAV HAZELA','M',1001,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(125,'associate proffesor','VASUDEV','M',1001,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(176,'professor','hajela','M',1001,NULL,NULL,7,'1stjuneadvjava@gmail.com',3434343434,'$2y$10$gjhgjhghjghjghlkjljkleMnPqjgIFr1kQFJhI6GcyfhH4z6hAAPe',NULL),(178,'professor','xyz','M',1001,NULL,NULL,3,'xyz@gmail.com',3434343434,NULL,NULL),(221,'proffesor','RKB','M',1002,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(222,'assistant proffesor','LALITA GUPTA','F',1002,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(223,'assistant proffesor','UTTU','M',1002,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(321,'assistant proffesor','abcd','M',1003,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(322,' proffesor','efgh','M',1003,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(421,' proffesor','PRIYANKA PALIWAL','F',1004,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(422,' associate proffesor','KANCHA','M',1004,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `faculty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedback` (
  `scholarNo` int(11) NOT NULL,
  `facultyId` int(11) NOT NULL,
  `cCode` varchar(11) NOT NULL,
  `que1` tinyint(4) DEFAULT NULL,
  `que2` tinyint(4) DEFAULT NULL,
  `que3` tinyint(4) DEFAULT NULL,
  `que4` tinyint(4) DEFAULT NULL,
  `que5` tinyint(4) DEFAULT NULL,
  `que6` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`scholarNo`,`facultyId`,`cCode`),
  KEY `scholarNo` (`scholarNo`),
  KEY `facultyId` (`facultyId`),
  KEY `cCode` (`cCode`),
  KEY `facultyId_2` (`facultyId`),
  CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`cCode`) REFERENCES `courses` (`cCode`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `feedback_ibfk_2` FOREIGN KEY (`facultyId`) REFERENCES `faculty` (`facultyId`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `feedback_ibfk_3` FOREIGN KEY (`scholarNo`) REFERENCES `student` (`scholarNo`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback`
--

LOCK TABLES `feedback` WRITE;
/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
INSERT INTO `feedback` VALUES (171112001,122,'CSE221',6,4,6,7,4,6),(171112014,122,'CSE221',5,5,5,5,5,5),(171112014,1004,'CSE221',5,5,5,5,5,5),(171112016,121,'CSE222',NULL,NULL,NULL,NULL,NULL,NULL),(171112016,122,'CSE222',5,5,5,5,5,5),(171112016,123,'CSE222',NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opts`
--

DROP TABLE IF EXISTS `opts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `opts` (
  `scholarNo` int(11) NOT NULL,
  `cCode` varchar(11) NOT NULL,
  PRIMARY KEY (`scholarNo`,`cCode`),
  KEY `cCode` (`cCode`),
  KEY `scholarNo` (`scholarNo`),
  CONSTRAINT `opts_ibfk_1` FOREIGN KEY (`cCode`) REFERENCES `courses` (`cCode`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `opts_ibfk_2` FOREIGN KEY (`scholarNo`) REFERENCES `student` (`scholarNo`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opts`
--

LOCK TABLES `opts` WRITE;
/*!40000 ALTER TABLE `opts` DISABLE KEYS */;
INSERT INTO `opts` VALUES (161112516,'EE321'),(161112516,'EE322'),(171112001,'CSE222'),(171112001,'CSE224'),(171112014,'CSE223'),(171112014,'CSE224'),(171112016,'CSE221'),(171112016,'CSE222'),(171112017,'CSE223'),(171112017,'CSE224'),(171112021,'ECE221'),(171112021,'ECE222'),(171112021,'ECE223'),(171112030,'CSE221'),(171112030,'CSE223'),(171112030,'CSE224'),(171112103,'CSE222'),(171112103,'CSE223'),(171112777,'ME221'),(171112777,'ME222');
/*!40000 ALTER TABLE `opts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student` (
  `scholarNo` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `sex` char(1) DEFAULT NULL,
  `programe` varchar(100) DEFAULT NULL,
  `dId` int(11) DEFAULT NULL,
  `sem` int(11) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phno` bigint(10) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `reflag` varchar(5) NOT NULL DEFAULT 'false',
  `validity` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`scholarNo`),
  KEY `dId` (`dId`),
  KEY `scholarNo` (`scholarNo`),
  CONSTRAINT `student_ibfk_1` FOREIGN KEY (`dId`) REFERENCES `department` (`dId`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES (161112516,'ADITYA SHRIVASTAVA','M','UG',1003,6,'aditya@gmail.com',123456709,'','1998-07-26','false',NULL),(171112001,'YUKTA TIWARI','F','UG',1001,4,'yutkatiwari@gmail.com',9826210298,'yukta','1998-07-02','true',NULL),(171112014,'KHUSHAGRA RAJ TIWARI','M','UG',1001,4,'ndiuiuasnd@gmail.com',32368438093,'manit@123','1999-02-03','true',NULL),(171112016,'RISHABH KULSHRESTHA','M','UG',1001,4,'rishabh@gmail.com',123456789,'$2y$10$gjhgjhghjghjghlkjljkleWNB/NwSbEd8l1R./NcFlSTulTNdNZVG','1999-06-07','true',NULL),(171112017,'VISHAL YADAV','M','UG',1001,4,'vishal@gmail.com',123453789,'$2y$10$gjhgjhghjghjghlkjljkle2W3RlYripeoQrl.mnNzYN78t82JI.3C','1998-02-07','true',NULL),(171112021,'UTKARSH SINHA','M','UG',1002,4,'utkarsh@gmail.com',123436789,NULL,'1999-02-09','false',NULL),(171112030,'HIMANI JOSHI','F','UG',1001,4,'himani@gmail.com',123436789,'','1998-03-08','false',NULL),(171112103,'NEERAJ KUMAR','M','UG',1001,4,'1stjuneadvjava@gmail.com',133456789,'$2y$10$gjhgjhghjghjghlkjljklefQnpchTiUUJ/xRERec1mUiFvhSc3vvy','1998-09-07','true','6f67476a1b462edfe67c'),(171112312,'NAMRATA JAIN','F','UG',1002,4,'namrata@gmail.com',123454789,'','1999-04-08','true',NULL),(171112777,'AVNEESH PATEL','M','UG',1004,4,'rishabh@gmail.com',123456789,'$2y$10$gjhgjhghjghjghlkjljkleeprrH7Qz8HABCHU4W2Jk627A6r6CKMS','1998-05-08','true',NULL);
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teachbyfaculty`
--

DROP TABLE IF EXISTS `teachbyfaculty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teachbyfaculty` (
  `facultyId` int(11) NOT NULL,
  `dId` int(11) NOT NULL,
  PRIMARY KEY (`facultyId`,`dId`),
  KEY `facultyId` (`facultyId`),
  KEY `dId` (`dId`),
  CONSTRAINT `teachbyfaculty_ibfk_1` FOREIGN KEY (`dId`) REFERENCES `department` (`dId`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `teachbyfaculty_ibfk_2` FOREIGN KEY (`facultyId`) REFERENCES `faculty` (`facultyId`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teachbyfaculty`
--

LOCK TABLES `teachbyfaculty` WRITE;
/*!40000 ALTER TABLE `teachbyfaculty` DISABLE KEYS */;
INSERT INTO `teachbyfaculty` VALUES (121,1001),(122,1001),(123,1001),(124,1001),(125,1001),(221,1002),(222,1002),(223,1002),(321,1003),(322,1003),(421,1004),(422,1004);
/*!40000 ALTER TABLE `teachbyfaculty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teaches`
--

DROP TABLE IF EXISTS `teaches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teaches` (
  `facultyId` int(11) NOT NULL,
  `cCode` varchar(11) NOT NULL,
  PRIMARY KEY (`facultyId`,`cCode`),
  KEY `facultyId` (`facultyId`),
  KEY `cCode` (`cCode`),
  CONSTRAINT `teaches_ibfk_1` FOREIGN KEY (`cCode`) REFERENCES `courses` (`cCode`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `teaches_ibfk_2` FOREIGN KEY (`facultyId`) REFERENCES `faculty` (`facultyId`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teaches`
--

LOCK TABLES `teaches` WRITE;
/*!40000 ALTER TABLE `teaches` DISABLE KEYS */;
INSERT INTO `teaches` VALUES (121,'CSE223'),(122,'CSE221'),(124,'CSE224'),(125,'CSE222'),(221,'ECE221'),(222,'ECE222'),(223,'ECE223'),(321,'EE321'),(322,'EE322'),(421,'ME221'),(422,'CSE222');
/*!40000 ALTER TABLE `teaches` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-03 18:41:46
