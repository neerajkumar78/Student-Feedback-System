


<!DOCTYPE html>
<html>
<head>
   <title>Students' Feedback System</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"> 
    <link rel='icon' href='../front-src/images/manitlogo3.jpg'>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!--
      <link rel='stylesheet' type='text/css' href='../front-src/pages/Rating.css'> -->
    <link rel='stylesheet' type='text/css' href="../front-src/pages/Rating.php" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous"/>
    <link rel='stylesheet' type='text/css' href='../front-src/pages/classic.css' /> 
    <style>
      .row{
        float:left;
        margin:4px;
        
        display:inline;
      }
      .workSpace{
    width: 55vw;}
    #some{
      display:grid;
    }
    .top-container{
      position:relative;
      bottom:-200%;
    }
    </style>
</head>
<body>
  <div class='header-container'>
        <a href='http://www.manit.ac.in/'  class='header'>
            <img class='logo' src='../front-src/images/manitlogo.png' alt='manit.ac.in' />
            <div class='title'>
                <div class='innertitle'>
                    MAULANA AZAD NATIONAL INSTITUTE OF TECHNOLOGY
                </div>
                Students' Feedback System
            </div>
        </a>
          <div class='nav'>
            <a href='../front-src/pages/index3.html' class='nav-btn'>
                Home
            </a>
            
            <a href="../back-src/logout.php?roll='a'" class='nav-btn'>
                    Logout
            </a>
            <?php
include 'operation.php';
$connection=mysqli_connect("localhost","root","","project");
session_start();

if(isset($_SESSION['adminId'])&&$_SESSION['role']=='a'){
   $adminId=$_SESSION['adminId'];
$query="SELECT * FROM admin WHERE adminId=$adminId";
$result=mysqli_query($connection,$query);
$tuple=mysqli_fetch_array($result);
if($tuple){
  $info['Name']=mysqli_real_escape_string($connection,$tuple['name']);
  $GLOBALS['name']=$info['Name'];
  $info['Admin Id']=mysqli_real_escape_string($connection,$tuple['adminId']);
  $info['Gender']=mysqli_real_escape_string($connection,$tuple['sex']);
  $info['Phone Number']=mysqli_real_escape_string($connection,$tuple['phno']);
  $info['Email Address']=mysqli_real_escape_string($connection,$tuple['email']);
?>
            <a href="../back-src/reset.php?adminId=<?php echo $adminId ?>&&roll='a'" class='nav-btn'>
                    change password
            </a>
           </div>
</div>
    <div id='home'></div>
     <div class='workSpace'>
    <article>
            <table class="w3-table-all w3-hoverable"> 
                <thead>
                    <!-- Edit here -->
                    <th>Welcome <?php echo $info['Name'] ?></th>
                </thead>
                <tbody>
               <?php foreach($info as $key => $value){ ?>
        <tr>
          <td><?php echo $key ?></td>
          <td><?php echo $value ?></td>
        </tr>
        <?php } ?>
                </tbody>
            </table>
    <?php 
}
}
?>
         </article>
         <aside>
            <div style='display: flex; flex-direction: column; justify-content: center; align-content: center;'>
                <img src='../front-src/images/manitlogo3.jpg' style='width: 20vw; align-self: center;'/>  
                <div style="text-align: center;">
                    <?php echo $GLOBALS['name'] ?>
                   
                </div>
            </div>
        </aside>
           <aside>
           <form action="updateadmin.php" method="POST">
            <div class="row">
	            <input  type="submit" name="update" value="udateadmin">
            </div>
             </form>

          <form action="updatestudent.php" method="POST">
            <div class="row">
	            <input   type="submit" name="update" value="udatestudent">
            </div>
             </form>

           <form action="updatefaculty.php" method="POST">
            <div class="row">
	            <input type="submit" name="update" value="udatefaculty">
            </div>
             </form>

             <form action="updatedepartment.php" method="POST">
              <div class="row">
	            <input  type="submit" name="update" value="udatedepartment">
            </div>
             </form>
               
               <form action="updatecourse.php" method="POST">
                <div class="row">
	            <input  type="submit" name="update" value="udatecourse">
            </div>
             </form>
             
            </br>
 

             <form action="view.php" method="POST">
              <div class="row">
	            <input  type="submit" name="udateadmin" value="viewadmin">
            </div>
             </form>

          <form action="viewstudent.php" method="POST">
            <div class="row">
	            <input  type="submit" name="viewt" value="viewstudent">
            </div>
             </form>

           <form action="viewfaculty.php" method="POST">
            <div class="row">
	            <input  type="submit" name="view" value="viewfaculty">
            </div>
             </form>

             <form action="viewdepartment.php" method="POST">
              <div class="row">
	            <input  type="submit" name="view" value="viewdepartment">
            </div>
             </form>
               
               <form action="viewcourse.php" method="POST">
                <div class="row">
	            <input  type="submit" name="view" value="viewcourse">
            </div>
             </form>
             
             </br>

            <form action="editadmin.php" method="POST">
              <div class="row">
	            <input  type="submit" name="edit" value="editadmin">
            </div>
             </form>

          <form action="editstudent.php" method="POST">
            <div class="row">
	            <input type="submit" name="edit" value="editstudent">
            </div>
             </form>

           <form action="editfaculty.php" method="POST">
            <div class="row">
	            <input  type="submit" name="edit" value="editfaculty">
            </div>
             </form>

             <form action="editdepartment.php" method="POST">
              <div class="row">
	            <input type="submit" name="edit" value="editdepartment">
            </div>
             </form>
               
               <form action="editcourse.php" method="POST">
                <div class="row">
	            <input  type="submit" name="edit" value="editcourse">
            </div>
             </form>
                  </br>
			<!-- <form action="editStudent.php?scholarNo=171112021" method="POST">
	            <input  type="submit" name="edit" value="editstudent">
             </form> -->
</aside>
<!-- <div id="id01" class="modal login-modal">
<form class="modal-content animate" method="POST" action="editStudent.php?scholarNo=171112021">
  <input  type="submit" name="edit" value="editstudent">
             </form>
 </div> -->
 <!----------
 <div class='login'>
  <div class='login-btn-container'>
               

                <div class='login-btn' 
                 onclick="document.querySelector('.login-button').setAttribute('value','s');">
                    <i class="fas fa-user-circle"><div>edit student</div></i>
                </div>

</div>
</div>


------------>



        
    </div>

    <footer>
        <div class='socialMedia'>
                <a href=""> <div class="fab fa-facebook-square media"></div></a>
                <a href=""><div class="fab fa-instagram media" ></div></a>
                <a href=""><div class="fab fa-google media" ></div></a>
        </div>
        <div class='copyright'>
                2019 All Rights Reserved Terms of Use and Privacy Policy
        </div>
    </footer> 
    <script>
        // Get the modal
        var modal = document.getElementById('id01');
        
        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
          if (event.target == modal) {
            modal.style.display = "none";
          }
        }
    </script> 
</body>
</html>