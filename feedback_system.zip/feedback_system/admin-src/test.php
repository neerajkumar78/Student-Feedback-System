<!DOCTYPE html>
<html>
<head>
	 <title>Students' Feedback System</title>
    <link rel='icon' href='../front-src/images/manitlogo3.jpg'></link>
    <link rel='stylesheet' type='text/css' href='../front-src/pages/basic.css'></link>
    <link rel='stylesheet' type='text/css' href='../front-src/pages/modal.css' />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
</head>
<body>
	<div class='header-container'>
        <a href='http://www.manit.ac.in/'  class='header'>
            <img class='logo' src='../front-src/images/manitlogo.png' alt='manit.ac.in' />
            <div class='title'>
                <div class='innertitle'>
                    MAULANA AZAD NATIONAL INSTITUTE OF TECHNOLOGY
                </div>
                Students' Feedback System
            </div>
        </a>
        <div class='nav'>
            <a href='#home' class='nav-btn'>
                Home
            </a>
            
            <a href='#logout.php' class='nav-btn'>
                    Logout
            </a>
            <a href='reset.php' class='nav-btn'>
                    change password
            </a>
        </div>
    </div>

<?php
$connection=mysqli_connect("localhost","root","","project");
session_start();
if(isset($_POST['update'])){
	$sex_domain=array('F'=>"FEMALE",'M'=>"MALE");
	?>
	<div id='home'></div>
    <div class='workSpace'>
       <div class="container">
			<form method="POST" action="#">
		<div class="row">
			<div class="col-25">
				<label for="name">Name</label>
			</div>
			<div class="col-75">
				<input type="text" id="name" name="name" placeholder="Your name..">
			</div>
		</div>
		<div class="row">
			<div class="col-25">
				<label for="scholarNo">Admin Id</label>
			</div>
			<div class="col-75">
				<input type="text" id="scholarNo" name="adminId" placeholder="Your adminId">
			</div>
		</div>
		<div class="row">
			<div class="col-25">
				<label for="sex">Sex</label>
			</div>
			<div class="col-75">
				<?php 
				foreach($sex_domain as $key=>$value){
					?>
				<input type="radio" name="sex" id="sex" value="<?php echo $key ?>" ><?php echo $value ?>
<?php } ?>

				<br>

				<div class="row">
			<div class="col-25">
				<label for="phno">Phone Number</label>
			</div>
			<div class="col-75">
				<input type="number" id="phno" name="phno" placeholder="Phone Number">
			</div>


		<div class="row">
			<div class="col-25">
				<label for="email">Email id</label>
			</div>
			<div class="col-75">
				<input type="email" name="email" placeholder='Email-id'  >
			</div>
	</div>
	
		<div class="row">
		<input type="submit" name="insert" value="Submit">
		<input type="reset" value="Reset">
		</div>
		</form>
<?php
}
?>

</div>
    </div>
    <div class='top-container'>
    <footer>
        <div class='socialMedia'>
                <a href=""> <div class="fab fa-facebook-square media" padding='10px'></div></a>
                <a href=""><div class="fab fa-instagram media" padding='10px'></div></a>
                <a href=""><div class="fab fa-google media" padding='10px'></div></a>
        </div>
        <div class='copyright'>
                2019 All Rights Reserved Terms of Use and Privacy Policy
        </div>
    </footer> 
</div>
</body>

</html>
<?php
if(isset($_POST['insert'])){
if($connection){
	echo "connection established";
	$name=mysqli_real_escape_string($connection,$_POST['name']);
	$adminId=mysqli_real_escape_string($connection,(int)$_POST['adminId']);
	$sex=mysqli_real_escape_string($connection,$_POST['sex']);
	
	$phno=mysqli_real_escape_string($connection,(int)$_POST['phno']);
	
	$email=mysqli_real_escape_string($connection,$_POST['email']);
$query="INSERT INTO admin(adminId,name,sex,phno,,email)";
$query .=" VALUES($adminId,'$name','$sex',$phno,'$email')";


  $resut=mysqli_query($connection,$query);
if(!$resut){
	echo "query not executed";
die(" ".mysqli_error($connection));
}

}
else{
	echo "connection is not esta blished";
}
}
?>
<!------------------------------------forgot password------->
<?php
/*require 'databaseconnect.php';
require 'redirect.php';
*/
$connection=mysqli_connect('localhost','root','','project');
if(!isset($_GET['email'])&&!isset($_GET['validity'])){
	//redirect('');
	header("Location:../front-src/pages/index3.html");
}

$validity=$_GET['validity'];
$query="SELECT * FROM student WHERE validity='$validity'";
$result=mysqli_query($connection,$query);
if(mysqli_num_rows($result)>=1){
if(isset($_POST['submit'])){
if(isset($_POST['password']) && isset($_POST['confirmpassword'])){
	$password=$_POST['password'];
	echo "$password";
$hashFormate="$2y$10$";
$x="gjhgjhghjghjghlkjljklmjkl";
$y=$hashFormate . $x;
$password=crypt($password,$y);
	
	$query="UPDATE student SET password='$password',validity='' WHERE email=?";
	$stmt=mysqli_prepare($connection,$query);
	if($stmt){
		mysqli_stmt_bind_param($stmt,"s",$_GET['email']);
		mysqli_stmt_execute($stmt);
		mysqli_stmt_fetch($stmt);
		if(mysqli_stmt_affected_rows($stmt)){
			mysqli_stmt_close($stmt);
			//redirect('login.php');
			header("Location:../front-src/pages/index3.html");
		}
	} 
	else{
		echo 'query failed as:'.mysqli_error($connection);
	}
}
}
}
else{
	http_response_code(404);
}
?>
<!DOCTYPE html>
<html>
	<head>
		<title>reset password</title>
	</head>
	<body>
		<h1>reset password</h1>
		</br>
		<form action="#" method="POST">
			Password       : <input type="password" name="password" placeholder="Password" id="password" required></br></br>
			Confirm password : <input type="password" placeholder="Confirm Password" name="confirmpassword" id="confirm_password" required></br></br>
			<button name="submit" type="submit" >Confirm</button>
			<script>
					var password = document.getElementById("password")
  					, confirm_password = document.getElementById("confirm_password");
					function validatePassword(){
  					if(password.value != confirm_password.value) {
    				confirm_password.setCustomValidity("Passwords Don't Match");
  					} else {
				    confirm_password.setCustomValidity('');
  					}
				}

				password.onchange = validatePassword;
				confirm_password.onkeyup = validatePassword;
			</script>
	   </form>
	</body>
</html>
<!-----------------------FEEDBACK2 TABLE TAGS -------------->

	<!----------------------------->
	<!------------------------------------------
		FROM FACULTY PROFILE---------------
		$query="SELECT facultyId,cCode,AVG(que1) ,AVG(que2) ,AVG(que3) ,AVG(que4),AVG(que5) ,AVG(que6)  from feedback GROUP BY facultyId,cCode HAVING (facultyId=$facultyId)";

$result=mysqli_query($connection,$query);
if($result){
  
  }
  else{
    echo mysqli_error($connection,$result);
  }
  <?php
while($tuple=mysqli_fetch_array($result)){
$cCode=$tuple['cCode'];
$que1=$tuple['AVG(que1)'];
$que2=$tuple['AVG(que2)'];
$que3=$tuple['AVG(que3)'];
$que4=$tuple['AVG(que4)'];
$que5=$tuple['AVG(que5)'];
$que6=$tuple['AVG(que6)'];
$avg=($que1+$que2+$que3+$que4+$que5+$que6)/6;

?>
<table>
      
      <tr>
        <td>Course Code</td>
        <td>question1</td>
        <td>question2</td>
        <td>question3</td>
        <td>question4</td>
        <td>question5</td>
        <td>question6</td>
      </tr>   
  </table> 

     <table>      
      <tr>
        <td><?php echo $cCode ?></td>
        <td><?php echo $que1 ?></td>
        <td><?php echo $que2 ?></td>
        <td><?php echo $que3 ?></td>
        <td><?php echo $que4 ?></td>
        <td><?php echo $que5 ?></td>
        <td><?php echo $que6 ?></td>
      </tr>
    
  </table>

  }
 ---------------------------END FROM FACULTY PROFILE------------>
