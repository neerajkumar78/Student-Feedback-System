<?php
ob_start();
session_start();
if(isset($_SESSION['scholarNo'])){
echo 'you logged in sccessfully';
echo $_SESSION['name'];
}
if(!isset($_SESSION['scholarNo'])){
	header("Location:login.php");}
?>
<br/>

<a href="logout.php">logout</a>
