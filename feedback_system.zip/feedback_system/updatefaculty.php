<?php
ob_start();
$connection=mysqli_connect('localhost','root','','feedbacksystem');
if(isset($_POST['submit'])){
     if($connection){
	echo "connection established";
	$facultyId=mysqli_real_escape_string($connection,$_POST['facultyId']);
	$post=mysqli_real_escape_string($connection,$_POST['post']);
	$name=mysqli_real_escape_string($connection,$_POST['name']);
	$sex=mysqli_real_escape_string($connection,$_POST['sex']);
	$qualification=mysqli_real_escape_string($connection,$_POST['qualification']);
	$areaOfInterest=mysqli_real_escape_string($connection,$_POST['areaOfInterest']);
	$did=mysqli_real_escape_string($connection,$_POST['did']);
	$experience=mysqli_real_escape_string($connection,$_POST['experience']);
	$phNo=mysqli_real_escape_string($connection,$_POST['phNo']);
	//$dob=mysqli_real_escape_string($connection,$_POST['dob']);
	$email=mysqli_real_escape_string($connection,$_POST['email']);
    $query="INSERT INTO faculty(facultyId,post,name,sex,did,qualification,areaOfInterest,experience,phNo,email)";
    $query .=" VALUES($facultyId,'$post','$name','$sex',$did,'$qualification','$areaOfInterest',$experience,$phNo,'$email')";
    $result=mysqli_query($connection,$query);
           if($result){
                header('Location:updateStudent.php');
	                  }
            else{
	             echo "query not executed";
                die(" ".mysqli_error($connection));
               }

       }
}
?>
<!DOCTYPE html>
<html>
<head>
	
	<title>update student information</title>
	<style>
	label{
		
		
		margin:10px;
	}
	input{
		border-radius:5px;
		margin-left:20px;
	}
	fieldset{
		width:35%;
	}
</style>
</head>
<body>
	<fieldset>
	<form method="POST" action="#">
			<label>Your Id:&nbsp &nbsp <input type="number" name="facultyId"/></label><br/>
		<label>Post:</label>
		<select name="post">
		<option value="mr">mr</option>
		<option value="mrs">mrs</option>
	</select><br/>
	<label>Name: &nbsp &nbsp &nbsp &nbsp    &nbsp &nbsp  <input type="text" name="name"/></label><br/>
    	<label>Sex:</label><br/>
		<input type="radio" name="sex" value="M">Male<br>
		<input type="radio" name="sex" value="F"/>Female<br>
	
	<br/>
	<label>Select Department:</label>
	<select name="did">
		
		<option  value="123">Computer Science And Engineering</option>
		<option  value="124">Mechanical Engineering</option>
		<option  value="125"/>Civil Engineering</option>
		<option  value="126">Electronics and Communication Engineering</option>
		<option  value="127"/>Electrical Engineering</option> 
	</select>
	<br/>
	<label>Qualification: &nbsp &nbsp &nbsp &nbsp    &nbsp &nbsp  <input type="text" name="qualification"/></label><br/>
	<label>areaOfInterest: &nbsp &nbsp &nbsp &nbsp    &nbsp &nbsp  <input type="text" name="areaOfInterest"/></label><br/>

	
	
	 <label>Years Of Experience:&nbsp &nbsp &nbsp<input type="number" name="experience"></label><br/>
	<br/>
    <label>Phone No:&nbsp &nbsp &nbsp<input type="number" name="phNo"></label><br/>
   <!-- <label>Date Of Birth:<input type="date('yy-m-l')" name="dob" placeholder='YY-MM-DD'/></label><br/>-->
    <label>Email:<input type="email" name="email" ></label><br/>
    <input type="submit" name="submit" value="submit">
</form>
</fieldset>
</body>
</html>
